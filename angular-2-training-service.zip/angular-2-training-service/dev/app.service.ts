import { Injectable } from '@angular/core';

@Injectable()
export class AppService {
  /*getMovies(): Promise<Movie[]> {
    return Promise.resolve(MOVIES);
  }*/
  getMovies(){
    return Promise.resolve(MOVIES);
  }
}

interface Movie {
    name: string;
    shortName: string;
    initialRelease: string;
    director: string;
    storyBy: string;
    description: string;
}

var MOVIES: Movie[] = [
  {
    name: "The Shawshank Redemption",
    shortName: "tsr",
    initialRelease: "September 23, 1994 (USA)",
    director: "Frank Darabont",
    storyBy: "Stephen King",
    description: "Andy Dufresne, a successful banker, is arrested for the murders of his wife and her lover, and is sentenced to life imprisonment at the Shawshank prison. He becomes the most unconventional prisoner."
  },
  {
    name: "The Godfather",
    shortName: "tgf",
    initialRelease: "March 15, 1972 (New York City)",
    director: "Francis Ford Coppola",
    storyBy: "Mario Puzo",
    description: "Don Vito Corleone, head of a mafia family, decides to hand over his empire to his youngest son Michael. However, his decision unintentionally puts the lives of his loved ones in grave danger."
  },
  {
    name: "The Dark Knight",
    shortName: "tdk",
    initialRelease: "July 18, 2008 (India)",
    director: "Christopher Nolan",
    storyBy: "",
    description: "Batman has a new foe, the Joker, who is an accomplished criminal hell-bent on decimating Gotham City. Together with Gordon and Harvey Dent, Batman struggles to thwart the Joker before it is too late."
  },
  {
    name: "Schindler's List",
    shortName: "scl",
    initialRelease: "November 30, 1993 (DC)",
    director: "Steven Spielberg",
    storyBy: "",
    description: "Oskar Schindler, a German industrialist and member of the Nazi party, tries to save his Jewish employees after witnessing the persecution of Jews in Poland."
  }
]
