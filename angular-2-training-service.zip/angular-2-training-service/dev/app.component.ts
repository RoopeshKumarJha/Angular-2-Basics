import { Component, OnInit } from '@angular/core';
import { MovieItemComponent } from './movie-item.component';
import { HighlighterDirective } from './highlighter.directive';
import { UnlessDirective } from './unless.directive';
import { AppService } from './app.service';

@Component({
  selector: 'movie-app',
  templateUrl: 'app/partials/app.html',
  styleUrls:['app/css/app.css'],
  directives: [MovieItemComponent, HighlighterDirective, UnlessDirective],
  providers: [AppService]
})
export class AppComponent {
  name: string;
  movies: Movie[];
  myColor: string;

  constructor(private appService: AppService) {
    //this.name = "Transformer";
    //this.movies = MOVIES;//["The Shawshank Redemption", "The Godfather", "The Dark Knight", "Schindler's List"];
    this.myColor = 'yellow';
  }

  getMovies(): void {
    //this.appService.getMovies().then(movies => this.movies = movies);
    this.appService.getMovies().then((movies){
      this.movies = movies;
    })
  }

  ngOnInit(): void {
    this.getMovies();
  }

  onLinkClick(movieSelected: string){
    //console.log("32236532");
    this.name = movieSelected;
  }

  addMovie(newMovie){
    //console.log(newMovie);
    this.movies.push({name: newMovie});
    this.name = '';
  }

}
