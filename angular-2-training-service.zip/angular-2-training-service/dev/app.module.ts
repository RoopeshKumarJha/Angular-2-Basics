import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';
import { AppComponent }   from './app.component';
import { MovieItemComponent } from './movie-item.component';
import { HighlighterDirective } from './highlighter.directive';
import { UnlessDirective } from './unless.directive';
import { AppService } from './app.service';


@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, MovieItemComponent, HighlighterDirective, UnlessDirective ],
  bootstrap:    [ AppComponent ],
  providers:    [AppService]
})

export class AppModule { }
