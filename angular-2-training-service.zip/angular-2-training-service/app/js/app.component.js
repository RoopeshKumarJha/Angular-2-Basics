"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var movie_item_component_1 = require('./movie-item.component');
var highlighter_directive_1 = require('./highlighter.directive');
var unless_directive_1 = require('./unless.directive');
var app_service_1 = require('./app.service');
var AppComponent = (function () {
    function AppComponent(appService) {
        this.appService = appService;
        //this.name = "Transformer";
        //this.movies = MOVIES;//["The Shawshank Redemption", "The Godfather", "The Dark Knight", "Schindler's List"];
        this.myColor = 'yellow';
    }
    AppComponent.prototype.getMovies = function () {
        var _this = this;
        //this.appService.getMovies().then(movies => this.movies = movies);
        this.appService.getMovies().then(function (movies) {
            _this.movies = movies;
        });
    };
    AppComponent.prototype.ngOnInit = function () {
        this.getMovies();
    };
    AppComponent.prototype.onLinkClick = function (movieSelected) {
        //console.log("32236532");
        this.name = movieSelected;
    };
    AppComponent.prototype.addMovie = function (newMovie) {
        //console.log(newMovie);
        this.movies.push({ name: newMovie });
        this.name = '';
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'movie-app',
            templateUrl: 'app/partials/app.html',
            styleUrls: ['app/css/app.css'],
            directives: [movie_item_component_1.MovieItemComponent, highlighter_directive_1.HighlighterDirective, unless_directive_1.UnlessDirective],
            providers: [app_service_1.AppService]
        }), 
        __metadata('design:paramtypes', [app_service_1.AppService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLHFCQUFrQyxlQUFlLENBQUMsQ0FBQTtBQUNsRCxxQ0FBbUMsd0JBQXdCLENBQUMsQ0FBQTtBQUM1RCxzQ0FBcUMseUJBQXlCLENBQUMsQ0FBQTtBQUMvRCxpQ0FBZ0Msb0JBQW9CLENBQUMsQ0FBQTtBQUNyRCw0QkFBMkIsZUFBZSxDQUFDLENBQUE7QUFTM0M7SUFLRSxzQkFBb0IsVUFBc0I7UUFBdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN4Qyw0QkFBNEI7UUFDNUIsOEdBQThHO1FBQzlHLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO0lBQzFCLENBQUM7SUFFRCxnQ0FBUyxHQUFUO1FBQUEsaUJBS0M7UUFKQyxtRUFBbUU7UUFDbkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBQyxNQUFNO1lBQ3RDLEtBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELCtCQUFRLEdBQVI7UUFDRSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELGtDQUFXLEdBQVgsVUFBWSxhQUFxQjtRQUMvQiwwQkFBMEI7UUFDMUIsSUFBSSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUM7SUFDNUIsQ0FBQztJQUVELCtCQUFRLEdBQVIsVUFBUyxRQUFRO1FBQ2Ysd0JBQXdCO1FBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7SUFDakIsQ0FBQztJQXRDSDtRQUFDLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsV0FBVztZQUNyQixXQUFXLEVBQUUsdUJBQXVCO1lBQ3BDLFNBQVMsRUFBQyxDQUFDLGlCQUFpQixDQUFDO1lBQzdCLFVBQVUsRUFBRSxDQUFDLHlDQUFrQixFQUFFLDRDQUFvQixFQUFFLGtDQUFlLENBQUM7WUFDdkUsU0FBUyxFQUFFLENBQUMsd0JBQVUsQ0FBQztTQUN4QixDQUFDOztvQkFBQTtJQWtDRixtQkFBQztBQUFELENBakNBLEFBaUNDLElBQUE7QUFqQ1ksb0JBQVksZUFpQ3hCLENBQUEiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNb3ZpZUl0ZW1Db21wb25lbnQgfSBmcm9tICcuL21vdmllLWl0ZW0uY29tcG9uZW50JztcbmltcG9ydCB7IEhpZ2hsaWdodGVyRGlyZWN0aXZlIH0gZnJvbSAnLi9oaWdobGlnaHRlci5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgVW5sZXNzRGlyZWN0aXZlIH0gZnJvbSAnLi91bmxlc3MuZGlyZWN0aXZlJztcbmltcG9ydCB7IEFwcFNlcnZpY2UgfSBmcm9tICcuL2FwcC5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbW92aWUtYXBwJyxcbiAgdGVtcGxhdGVVcmw6ICdhcHAvcGFydGlhbHMvYXBwLmh0bWwnLFxuICBzdHlsZVVybHM6WydhcHAvY3NzL2FwcC5jc3MnXSxcbiAgZGlyZWN0aXZlczogW01vdmllSXRlbUNvbXBvbmVudCwgSGlnaGxpZ2h0ZXJEaXJlY3RpdmUsIFVubGVzc0RpcmVjdGl2ZV0sXG4gIHByb3ZpZGVyczogW0FwcFNlcnZpY2VdXG59KVxuZXhwb3J0IGNsYXNzIEFwcENvbXBvbmVudCB7XG4gIG5hbWU6IHN0cmluZztcbiAgbW92aWVzOiBNb3ZpZVtdO1xuICBteUNvbG9yOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBhcHBTZXJ2aWNlOiBBcHBTZXJ2aWNlKSB7XG4gICAgLy90aGlzLm5hbWUgPSBcIlRyYW5zZm9ybWVyXCI7XG4gICAgLy90aGlzLm1vdmllcyA9IE1PVklFUzsvL1tcIlRoZSBTaGF3c2hhbmsgUmVkZW1wdGlvblwiLCBcIlRoZSBHb2RmYXRoZXJcIiwgXCJUaGUgRGFyayBLbmlnaHRcIiwgXCJTY2hpbmRsZXIncyBMaXN0XCJdO1xuICAgIHRoaXMubXlDb2xvciA9ICd5ZWxsb3cnO1xuICB9XG5cbiAgZ2V0TW92aWVzKCk6IHZvaWQge1xuICAgIC8vdGhpcy5hcHBTZXJ2aWNlLmdldE1vdmllcygpLnRoZW4obW92aWVzID0+IHRoaXMubW92aWVzID0gbW92aWVzKTtcbiAgICB0aGlzLmFwcFNlcnZpY2UuZ2V0TW92aWVzKCkudGhlbigobW92aWVzKXtcbiAgICAgIHRoaXMubW92aWVzID0gbW92aWVzO1xuICAgIH0pXG4gIH1cblxuICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLmdldE1vdmllcygpO1xuICB9XG5cbiAgb25MaW5rQ2xpY2sobW92aWVTZWxlY3RlZDogc3RyaW5nKXtcbiAgICAvL2NvbnNvbGUubG9nKFwiMzIyMzY1MzJcIik7XG4gICAgdGhpcy5uYW1lID0gbW92aWVTZWxlY3RlZDtcbiAgfVxuXG4gIGFkZE1vdmllKG5ld01vdmllKXtcbiAgICAvL2NvbnNvbGUubG9nKG5ld01vdmllKTtcbiAgICB0aGlzLm1vdmllcy5wdXNoKHtuYW1lOiBuZXdNb3ZpZX0pO1xuICAgIHRoaXMubmFtZSA9ICcnO1xuICB9XG5cbn1cbiJdfQ==
