"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var forms_1 = require('@angular/forms');
var app_component_1 = require('./app.component');
var movie_item_component_1 = require('./movie-item.component');
var highlighter_directive_1 = require('./highlighter.directive');
var unless_directive_1 = require('./unless.directive');
var app_service_1 = require('./app.service');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [platform_browser_1.BrowserModule, forms_1.FormsModule],
            declarations: [app_component_1.AppComponent, movie_item_component_1.MovieItemComponent, highlighter_directive_1.HighlighterDirective, unless_directive_1.UnlessDirective],
            bootstrap: [app_component_1.AppComponent],
            providers: [app_service_1.AppService]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLHFCQUE4QixlQUFlLENBQUMsQ0FBQTtBQUM5QyxpQ0FBOEIsMkJBQTJCLENBQUMsQ0FBQTtBQUMxRCxzQkFBOEIsZ0JBQWdCLENBQUMsQ0FBQTtBQUMvQyw4QkFBK0IsaUJBQWlCLENBQUMsQ0FBQTtBQUNqRCxxQ0FBbUMsd0JBQXdCLENBQUMsQ0FBQTtBQUM1RCxzQ0FBcUMseUJBQXlCLENBQUMsQ0FBQTtBQUMvRCxpQ0FBZ0Msb0JBQW9CLENBQUMsQ0FBQTtBQUNyRCw0QkFBMkIsZUFBZSxDQUFDLENBQUE7QUFVM0M7SUFBQTtJQUF5QixDQUFDO0lBUDFCO1FBQUMsZUFBUSxDQUFDO1lBQ1IsT0FBTyxFQUFPLENBQUUsZ0NBQWEsRUFBRSxtQkFBVyxDQUFFO1lBQzVDLFlBQVksRUFBRSxDQUFFLDRCQUFZLEVBQUUseUNBQWtCLEVBQUUsNENBQW9CLEVBQUUsa0NBQWUsQ0FBRTtZQUN6RixTQUFTLEVBQUssQ0FBRSw0QkFBWSxDQUFFO1lBQzlCLFNBQVMsRUFBSyxDQUFDLHdCQUFVLENBQUM7U0FDM0IsQ0FBQzs7aUJBQUE7SUFFdUIsZ0JBQUM7QUFBRCxDQUF6QixBQUEwQixJQUFBO0FBQWIsaUJBQVMsWUFBSSxDQUFBIiwiZmlsZSI6ImFwcC5tb2R1bGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9ICAgICAgZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCcm93c2VyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSB9ICAgZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgQXBwQ29tcG9uZW50IH0gICBmcm9tICcuL2FwcC5jb21wb25lbnQnO1xuaW1wb3J0IHsgTW92aWVJdGVtQ29tcG9uZW50IH0gZnJvbSAnLi9tb3ZpZS1pdGVtLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBIaWdobGlnaHRlckRpcmVjdGl2ZSB9IGZyb20gJy4vaGlnaGxpZ2h0ZXIuZGlyZWN0aXZlJztcbmltcG9ydCB7IFVubGVzc0RpcmVjdGl2ZSB9IGZyb20gJy4vdW5sZXNzLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBBcHBTZXJ2aWNlIH0gZnJvbSAnLi9hcHAuc2VydmljZSc7XG5cblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogICAgICBbIEJyb3dzZXJNb2R1bGUsIEZvcm1zTW9kdWxlIF0sXG4gIGRlY2xhcmF0aW9uczogWyBBcHBDb21wb25lbnQsIE1vdmllSXRlbUNvbXBvbmVudCwgSGlnaGxpZ2h0ZXJEaXJlY3RpdmUsIFVubGVzc0RpcmVjdGl2ZSBdLFxuICBib290c3RyYXA6ICAgIFsgQXBwQ29tcG9uZW50IF0sXG4gIHByb3ZpZGVyczogICAgW0FwcFNlcnZpY2VdXG59KVxuXG5leHBvcnQgY2xhc3MgQXBwTW9kdWxlIHsgfVxuIl19
