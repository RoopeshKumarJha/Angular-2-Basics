"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var AppService = (function () {
    function AppService() {
    }
    /*getMovies(): Promise<Movie[]> {
      return Promise.resolve(MOVIES);
    }*/
    AppService.prototype.getMovies = function () {
        return Promise.resolve(MOVIES);
    };
    AppService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], AppService);
    return AppService;
}());
exports.AppService = AppService;
var MOVIES = [
    {
        name: "The Shawshank Redemption",
        shortName: "tsr",
        initialRelease: "September 23, 1994 (USA)",
        director: "Frank Darabont",
        storyBy: "Stephen King",
        description: "Andy Dufresne, a successful banker, is arrested for the murders of his wife and her lover, and is sentenced to life imprisonment at the Shawshank prison. He becomes the most unconventional prisoner."
    },
    {
        name: "The Godfather",
        shortName: "tgf",
        initialRelease: "March 15, 1972 (New York City)",
        director: "Francis Ford Coppola",
        storyBy: "Mario Puzo",
        description: "Don Vito Corleone, head of a mafia family, decides to hand over his empire to his youngest son Michael. However, his decision unintentionally puts the lives of his loved ones in grave danger."
    },
    {
        name: "The Dark Knight",
        shortName: "tdk",
        initialRelease: "July 18, 2008 (India)",
        director: "Christopher Nolan",
        storyBy: "",
        description: "Batman has a new foe, the Joker, who is an accomplished criminal hell-bent on decimating Gotham City. Together with Gordon and Harvey Dent, Batman struggles to thwart the Joker before it is too late."
    },
    {
        name: "Schindler's List",
        shortName: "scl",
        initialRelease: "November 30, 1993 (DC)",
        director: "Steven Spielberg",
        storyBy: "",
        description: "Oskar Schindler, a German industrialist and member of the Nazi party, tries to save his Jewish employees after witnessing the persecution of Jews in Poland."
    }
];

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxxQkFBMkIsZUFBZSxDQUFDLENBQUE7QUFHM0M7SUFBQTtJQU9BLENBQUM7SUFOQzs7T0FFRztJQUNILDhCQUFTLEdBQVQ7UUFDRSxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBUEg7UUFBQyxpQkFBVSxFQUFFOztrQkFBQTtJQVFiLGlCQUFDO0FBQUQsQ0FQQSxBQU9DLElBQUE7QUFQWSxrQkFBVSxhQU90QixDQUFBO0FBV0QsSUFBSSxNQUFNLEdBQVk7SUFDcEI7UUFDRSxJQUFJLEVBQUUsMEJBQTBCO1FBQ2hDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLGNBQWMsRUFBRSwwQkFBMEI7UUFDMUMsUUFBUSxFQUFFLGdCQUFnQjtRQUMxQixPQUFPLEVBQUUsY0FBYztRQUN2QixXQUFXLEVBQUUsd01BQXdNO0tBQ3ROO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsZUFBZTtRQUNyQixTQUFTLEVBQUUsS0FBSztRQUNoQixjQUFjLEVBQUUsZ0NBQWdDO1FBQ2hELFFBQVEsRUFBRSxzQkFBc0I7UUFDaEMsT0FBTyxFQUFFLFlBQVk7UUFDckIsV0FBVyxFQUFFLGlNQUFpTTtLQUMvTTtJQUNEO1FBQ0UsSUFBSSxFQUFFLGlCQUFpQjtRQUN2QixTQUFTLEVBQUUsS0FBSztRQUNoQixjQUFjLEVBQUUsdUJBQXVCO1FBQ3ZDLFFBQVEsRUFBRSxtQkFBbUI7UUFDN0IsT0FBTyxFQUFFLEVBQUU7UUFDWCxXQUFXLEVBQUUseU1BQXlNO0tBQ3ZOO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsa0JBQWtCO1FBQ3hCLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLGNBQWMsRUFBRSx3QkFBd0I7UUFDeEMsUUFBUSxFQUFFLGtCQUFrQjtRQUM1QixPQUFPLEVBQUUsRUFBRTtRQUNYLFdBQVcsRUFBRSw4SkFBOEo7S0FDNUs7Q0FDRixDQUFBIiwiZmlsZSI6ImFwcC5zZXJ2aWNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgQXBwU2VydmljZSB7XG4gIC8qZ2V0TW92aWVzKCk6IFByb21pc2U8TW92aWVbXT4ge1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoTU9WSUVTKTtcbiAgfSovXG4gIGdldE1vdmllcygpe1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoTU9WSUVTKTtcbiAgfVxufVxuXG5pbnRlcmZhY2UgTW92aWUge1xuICAgIG5hbWU6IHN0cmluZztcbiAgICBzaG9ydE5hbWU6IHN0cmluZztcbiAgICBpbml0aWFsUmVsZWFzZTogc3RyaW5nO1xuICAgIGRpcmVjdG9yOiBzdHJpbmc7XG4gICAgc3RvcnlCeTogc3RyaW5nO1xuICAgIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG59XG5cbnZhciBNT1ZJRVM6IE1vdmllW10gPSBbXG4gIHtcbiAgICBuYW1lOiBcIlRoZSBTaGF3c2hhbmsgUmVkZW1wdGlvblwiLFxuICAgIHNob3J0TmFtZTogXCJ0c3JcIixcbiAgICBpbml0aWFsUmVsZWFzZTogXCJTZXB0ZW1iZXIgMjMsIDE5OTQgKFVTQSlcIixcbiAgICBkaXJlY3RvcjogXCJGcmFuayBEYXJhYm9udFwiLFxuICAgIHN0b3J5Qnk6IFwiU3RlcGhlbiBLaW5nXCIsXG4gICAgZGVzY3JpcHRpb246IFwiQW5keSBEdWZyZXNuZSwgYSBzdWNjZXNzZnVsIGJhbmtlciwgaXMgYXJyZXN0ZWQgZm9yIHRoZSBtdXJkZXJzIG9mIGhpcyB3aWZlIGFuZCBoZXIgbG92ZXIsIGFuZCBpcyBzZW50ZW5jZWQgdG8gbGlmZSBpbXByaXNvbm1lbnQgYXQgdGhlIFNoYXdzaGFuayBwcmlzb24uIEhlIGJlY29tZXMgdGhlIG1vc3QgdW5jb252ZW50aW9uYWwgcHJpc29uZXIuXCJcbiAgfSxcbiAge1xuICAgIG5hbWU6IFwiVGhlIEdvZGZhdGhlclwiLFxuICAgIHNob3J0TmFtZTogXCJ0Z2ZcIixcbiAgICBpbml0aWFsUmVsZWFzZTogXCJNYXJjaCAxNSwgMTk3MiAoTmV3IFlvcmsgQ2l0eSlcIixcbiAgICBkaXJlY3RvcjogXCJGcmFuY2lzIEZvcmQgQ29wcG9sYVwiLFxuICAgIHN0b3J5Qnk6IFwiTWFyaW8gUHV6b1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkRvbiBWaXRvIENvcmxlb25lLCBoZWFkIG9mIGEgbWFmaWEgZmFtaWx5LCBkZWNpZGVzIHRvIGhhbmQgb3ZlciBoaXMgZW1waXJlIHRvIGhpcyB5b3VuZ2VzdCBzb24gTWljaGFlbC4gSG93ZXZlciwgaGlzIGRlY2lzaW9uIHVuaW50ZW50aW9uYWxseSBwdXRzIHRoZSBsaXZlcyBvZiBoaXMgbG92ZWQgb25lcyBpbiBncmF2ZSBkYW5nZXIuXCJcbiAgfSxcbiAge1xuICAgIG5hbWU6IFwiVGhlIERhcmsgS25pZ2h0XCIsXG4gICAgc2hvcnROYW1lOiBcInRka1wiLFxuICAgIGluaXRpYWxSZWxlYXNlOiBcIkp1bHkgMTgsIDIwMDggKEluZGlhKVwiLFxuICAgIGRpcmVjdG9yOiBcIkNocmlzdG9waGVyIE5vbGFuXCIsXG4gICAgc3RvcnlCeTogXCJcIixcbiAgICBkZXNjcmlwdGlvbjogXCJCYXRtYW4gaGFzIGEgbmV3IGZvZSwgdGhlIEpva2VyLCB3aG8gaXMgYW4gYWNjb21wbGlzaGVkIGNyaW1pbmFsIGhlbGwtYmVudCBvbiBkZWNpbWF0aW5nIEdvdGhhbSBDaXR5LiBUb2dldGhlciB3aXRoIEdvcmRvbiBhbmQgSGFydmV5IERlbnQsIEJhdG1hbiBzdHJ1Z2dsZXMgdG8gdGh3YXJ0IHRoZSBKb2tlciBiZWZvcmUgaXQgaXMgdG9vIGxhdGUuXCJcbiAgfSxcbiAge1xuICAgIG5hbWU6IFwiU2NoaW5kbGVyJ3MgTGlzdFwiLFxuICAgIHNob3J0TmFtZTogXCJzY2xcIixcbiAgICBpbml0aWFsUmVsZWFzZTogXCJOb3ZlbWJlciAzMCwgMTk5MyAoREMpXCIsXG4gICAgZGlyZWN0b3I6IFwiU3RldmVuIFNwaWVsYmVyZ1wiLFxuICAgIHN0b3J5Qnk6IFwiXCIsXG4gICAgZGVzY3JpcHRpb246IFwiT3NrYXIgU2NoaW5kbGVyLCBhIEdlcm1hbiBpbmR1c3RyaWFsaXN0IGFuZCBtZW1iZXIgb2YgdGhlIE5hemkgcGFydHksIHRyaWVzIHRvIHNhdmUgaGlzIEpld2lzaCBlbXBsb3llZXMgYWZ0ZXIgd2l0bmVzc2luZyB0aGUgcGVyc2VjdXRpb24gb2YgSmV3cyBpbiBQb2xhbmQuXCJcbiAgfVxuXVxuIl19
