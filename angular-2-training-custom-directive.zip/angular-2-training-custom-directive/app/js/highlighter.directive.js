"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var HighlighterDirective = (function () {
    function HighlighterDirective(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        //console.log(renderer);
        //renderer.setElementStyle(el.nativeElement, 'color', 'red');
    }
    HighlighterDirective.prototype.onMouseEnter = function () {
        this.highlight(this.highlightColor || 'green');
    };
    HighlighterDirective.prototype.onMouseLeave = function () {
        this.highlight(null);
    };
    HighlighterDirective.prototype.highlight = function (color) {
        this.renderer.setElementStyle(this.el.nativeElement, 'color', color);
    };
    __decorate([
        core_1.Input('highlighter'), 
        __metadata('design:type', String)
    ], HighlighterDirective.prototype, "highlightColor", void 0);
    __decorate([
        core_1.HostListener('mouseenter'), 
        __metadata('design:type', Function), 
        __metadata('design:paramtypes', []), 
        __metadata('design:returntype', void 0)
    ], HighlighterDirective.prototype, "onMouseEnter", null);
    __decorate([
        core_1.HostListener('mouseleave'), 
        __metadata('design:type', Function), 
        __metadata('design:paramtypes', []), 
        __metadata('design:returntype', void 0)
    ], HighlighterDirective.prototype, "onMouseLeave", null);
    HighlighterDirective = __decorate([
        core_1.Directive({
            selector: '[highlighter]'
        }), 
        __metadata('design:paramtypes', [core_1.ElementRef, core_1.Renderer])
    ], HighlighterDirective);
    return HighlighterDirective;
}());
exports.HighlighterDirective = HighlighterDirective;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhpZ2hsaWdodGVyLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEscUJBQXFFLGVBQWUsQ0FBQyxDQUFBO0FBS3JGO0lBRUUsOEJBQW9CLEVBQWMsRUFBVSxRQUFrQjtRQUExQyxPQUFFLEdBQUYsRUFBRSxDQUFZO1FBQVUsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUM1RCx3QkFBd0I7UUFDeEIsNkRBQTZEO0lBQy9ELENBQUM7SUFJMkIsMkNBQVksR0FBWjtRQUMxQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxjQUFjLElBQUksT0FBTyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUUyQiwyQ0FBWSxHQUFaO1FBQzFCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDdEIsQ0FBQztJQUVPLHdDQUFTLEdBQWpCLFVBQWtCLEtBQWE7UUFDN0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7SUFaRDtRQUFDLFlBQUssQ0FBQyxhQUFhLENBQUM7O2dFQUFBO0lBRXJCO1FBQUMsbUJBQVksQ0FBQyxZQUFZLENBQUM7Ozs7NERBQUE7SUFJM0I7UUFBQyxtQkFBWSxDQUFDLFlBQVksQ0FBQzs7Ozs0REFBQTtJQWhCN0I7UUFBQyxnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLGVBQWU7U0FDMUIsQ0FBQzs7NEJBQUE7SUFzQkYsMkJBQUM7QUFBRCxDQXJCQSxBQXFCQyxJQUFBO0FBckJZLDRCQUFvQix1QkFxQmhDLENBQUEiLCJmaWxlIjoiaGlnaGxpZ2h0ZXIuZGlyZWN0aXZlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBFbGVtZW50UmVmLCBIb3N0TGlzdGVuZXIsIElucHV0LCBSZW5kZXJlciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaGlnaGxpZ2h0ZXJdJ1xufSlcbmV4cG9ydCBjbGFzcyBIaWdobGlnaHRlckRpcmVjdGl2ZSB7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBlbDogRWxlbWVudFJlZiwgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIpIHtcbiAgICAvL2NvbnNvbGUubG9nKHJlbmRlcmVyKTtcbiAgICAvL3JlbmRlcmVyLnNldEVsZW1lbnRTdHlsZShlbC5uYXRpdmVFbGVtZW50LCAnY29sb3InLCAncmVkJyk7XG4gIH1cblxuICBASW5wdXQoJ2hpZ2hsaWdodGVyJykgaGlnaGxpZ2h0Q29sb3I6IHN0cmluZztcblxuICBASG9zdExpc3RlbmVyKCdtb3VzZWVudGVyJykgb25Nb3VzZUVudGVyKCkge1xuICAgIHRoaXMuaGlnaGxpZ2h0KHRoaXMuaGlnaGxpZ2h0Q29sb3IgfHwgJ2dyZWVuJyk7XG4gIH1cblxuICBASG9zdExpc3RlbmVyKCdtb3VzZWxlYXZlJykgb25Nb3VzZUxlYXZlKCkge1xuICAgIHRoaXMuaGlnaGxpZ2h0KG51bGwpXG4gIH1cblxuICBwcml2YXRlIGhpZ2hsaWdodChjb2xvcjogc3RyaW5nKSB7XG4gICAgdGhpcy5yZW5kZXJlci5zZXRFbGVtZW50U3R5bGUodGhpcy5lbC5uYXRpdmVFbGVtZW50LCAnY29sb3InLCBjb2xvcik7XG4gIH1cblxufVxuIl19
