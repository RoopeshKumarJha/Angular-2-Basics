"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var MovieItemComponent = (function () {
    function MovieItemComponent() {
    }
    MovieItemComponent = __decorate([
        core_1.Component({
            selector: 'movie-item',
            template: "\n    {{movie.name}}\n    {{initialMovie}}\n  ",
            inputs: ['movie', 'initialMovie']
        }), 
        __metadata('design:paramtypes', [])
    ], MovieItemComponent);
    return MovieItemComponent;
}());
exports.MovieItemComponent = MovieItemComponent;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vdmllLWl0ZW0uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxxQkFBMEIsZUFBZSxDQUFDLENBQUE7QUFXMUM7SUFBQTtJQUVBLENBQUM7SUFWRDtRQUFDLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsWUFBWTtZQUN0QixRQUFRLEVBQUUsZ0RBR1Q7WUFDRCxNQUFNLEVBQUUsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO1NBQ2xDLENBQUM7OzBCQUFBO0lBR0YseUJBQUM7QUFBRCxDQUZBLEFBRUMsSUFBQTtBQUZZLDBCQUFrQixxQkFFOUIsQ0FBQSIsImZpbGUiOiJtb3ZpZS1pdGVtLmNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ21vdmllLWl0ZW0nLFxuICB0ZW1wbGF0ZTogYFxuICAgIHt7bW92aWUubmFtZX19XG4gICAge3tpbml0aWFsTW92aWV9fVxuICBgLFxuICBpbnB1dHM6IFsnbW92aWUnLCAnaW5pdGlhbE1vdmllJ11cbn0pXG5leHBvcnQgY2xhc3MgTW92aWVJdGVtQ29tcG9uZW50IHtcblxufVxuIl19
