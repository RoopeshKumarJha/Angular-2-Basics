import { Component } from '@angular/core';


@Component({
  selector: 'movie-item',
  template: `
    {{movie.name}}
    {{initialMovie}}
  `,
  inputs: ['movie', 'initialMovie']
})
export class MovieItemComponent {

}
