import { Directive, ElementRef, HostListener, Input, Renderer } from '@angular/core';

@Directive({
  selector: '[highlighter]'
})
export class HighlighterDirective {

  constructor(private el: ElementRef, private renderer: Renderer) {
    //console.log(renderer);
    //renderer.setElementStyle(el.nativeElement, 'color', 'red');
  }

  @Input('highlighter') highlightColor: string;

  @HostListener('mouseenter') onMouseEnter() {
    this.highlight(this.highlightColor || 'green');
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.highlight(null)
  }

  private highlight(color: string) {
    this.renderer.setElementStyle(this.el.nativeElement, 'color', color);
  }

}
