"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var AppComponent = (function () {
    function AppComponent() {
        this.name = "New Age";
        this.movies = ["The Shawshank Redemption", "The Godfather", "The Dark Knight", "Schindler's List"];
    }
    AppComponent.prototype.onClick = function (movieName) {
        this.name = movieName;
    };
    AppComponent.prototype.addMovie = function (movieToAdd) {
        this.movies.push(movieToAdd);
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'movie-app',
            templateUrl: 'app/partials/app.html',
            styleUrls: ['app/css/app.css']
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLHFCQUEwQixlQUFlLENBQUMsQ0FBQTtBQVExQztJQUlFO1FBQ0UsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7UUFDdEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLDBCQUEwQixFQUFFLGVBQWUsRUFBRSxpQkFBaUIsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JHLENBQUM7SUFFRCw4QkFBTyxHQUFQLFVBQVEsU0FBUztRQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDO0lBQ3hCLENBQUM7SUFFRCwrQkFBUSxHQUFSLFVBQVMsVUFBVTtRQUNqQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBckJIO1FBQUMsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxXQUFXO1lBQ3JCLFdBQVcsRUFBRSx1QkFBdUI7WUFDcEMsU0FBUyxFQUFFLENBQUMsaUJBQWlCLENBQUM7U0FDL0IsQ0FBQzs7b0JBQUE7SUFrQkYsbUJBQUM7QUFBRCxDQWhCQSxBQWdCQyxJQUFBO0FBaEJZLG9CQUFZLGVBZ0J4QixDQUFBIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbW92aWUtYXBwJyxcbiAgdGVtcGxhdGVVcmw6ICdhcHAvcGFydGlhbHMvYXBwLmh0bWwnLFxuICBzdHlsZVVybHM6IFsnYXBwL2Nzcy9hcHAuY3NzJ11cbn0pXG5cbmV4cG9ydCBjbGFzcyBBcHBDb21wb25lbnQge1xuICBuYW1lOiBzdHJpbmc7XG4gIG1vdmllczogYW55O1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMubmFtZSA9IFwiTmV3IEFnZVwiO1xuICAgIHRoaXMubW92aWVzID0gW1wiVGhlIFNoYXdzaGFuayBSZWRlbXB0aW9uXCIsIFwiVGhlIEdvZGZhdGhlclwiLCBcIlRoZSBEYXJrIEtuaWdodFwiLCBcIlNjaGluZGxlcidzIExpc3RcIl07XG4gIH1cblxuICBvbkNsaWNrKG1vdmllTmFtZSkge1xuICAgIHRoaXMubmFtZSA9IG1vdmllTmFtZTtcbiAgfVxuXG4gIGFkZE1vdmllKG1vdmllVG9BZGQpIHtcbiAgICB0aGlzLm1vdmllcy5wdXNoKG1vdmllVG9BZGQpO1xuICB9XG59XG4iXX0=
