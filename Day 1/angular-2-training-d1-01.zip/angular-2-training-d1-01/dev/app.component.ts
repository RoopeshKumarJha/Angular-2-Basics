import { Component } from '@angular/core';

@Component({
  selector: 'movie-app',
  templateUrl: 'app/partials/app.html',
  styleUrls: ['app/css/app.css']
})

export class AppComponent {
  name: string;
  movies: any;

  constructor() {
    this.name = "New Age";
    this.movies = ["The Shawshank Redemption", "The Godfather", "The Dark Knight", "Schindler's List"];
  }

  onClick(movieName) {
    this.name = movieName;
  }

  addMovie(movieToAdd) {
    this.movies.push(movieToAdd);
  }
}
