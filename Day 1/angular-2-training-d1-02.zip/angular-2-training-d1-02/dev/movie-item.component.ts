import {Component} from '@angular/core';

@Component ({
  selector: 'movie-item',
  templateUrl: 'app/partials/movieitem.html',
  styles : [`
  img {
    display: block;
    float: left;
    width: 60px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    margin-right: 10px;
    margin-bottom: 10px;
    width: 50px;
  }
  `, 'h2 { margin-top: 0;}'],
  inputs: ['movie']
})

export class MovieItemComponent {}
