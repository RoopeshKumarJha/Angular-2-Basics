"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var MovieItemComponent = (function () {
    function MovieItemComponent() {
    }
    MovieItemComponent = __decorate([
        core_1.Component({
            selector: 'movie-item',
            templateUrl: 'app/partials/movieitem.html',
            styles: ["\n  img {\n    display: block;\n    float: left;\n    width: 60px;\n    -webkit-border-radius: 5px;\n    border-radius: 5px;\n    margin-right: 10px;\n    margin-bottom: 10px;\n    width: 50px;\n  }\n  ", 'h2 { margin-top: 0;}'],
            inputs: ['movie']
        }), 
        __metadata('design:paramtypes', [])
    ], MovieItemComponent);
    return MovieItemComponent;
}());
exports.MovieItemComponent = MovieItemComponent;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vdmllLWl0ZW0uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxxQkFBd0IsZUFBZSxDQUFDLENBQUE7QUFvQnhDO0lBQUE7SUFBaUMsQ0FBQztJQWxCbEM7UUFBQyxnQkFBUyxDQUFFO1lBQ1YsUUFBUSxFQUFFLFlBQVk7WUFDdEIsV0FBVyxFQUFFLDZCQUE2QjtZQUMxQyxNQUFNLEVBQUcsQ0FBQyw0TUFXVCxFQUFFLHNCQUFzQixDQUFDO1lBQzFCLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQztTQUNsQixDQUFDOzswQkFBQTtJQUUrQix5QkFBQztBQUFELENBQWpDLEFBQWtDLElBQUE7QUFBckIsMEJBQWtCLHFCQUFHLENBQUEiLCJmaWxlIjoibW92aWUtaXRlbS5jb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBDb21wb25lbnQgKHtcbiAgc2VsZWN0b3I6ICdtb3ZpZS1pdGVtJyxcbiAgdGVtcGxhdGVVcmw6ICdhcHAvcGFydGlhbHMvbW92aWVpdGVtLmh0bWwnLFxuICBzdHlsZXMgOiBbYFxuICBpbWcge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIC13ZWJraXQtYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICB3aWR0aDogNTBweDtcbiAgfVxuICBgLCAnaDIgeyBtYXJnaW4tdG9wOiAwO30nXSxcbiAgaW5wdXRzOiBbJ21vdmllJ11cbn0pXG5cbmV4cG9ydCBjbGFzcyBNb3ZpZUl0ZW1Db21wb25lbnQge31cbiJdfQ==
