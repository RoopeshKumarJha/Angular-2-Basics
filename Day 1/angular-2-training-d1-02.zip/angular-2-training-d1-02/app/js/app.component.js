"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var movie_item_component_1 = require('./movie-item.component');
var AppComponent = (function () {
    function AppComponent() {
        this.movies = MOVIES;
    }
    AppComponent = __decorate([
        core_1.Component({
            selector: 'movie-app',
            templateUrl: 'app/partials/app.html',
            styleUrls: ['app/css/app.css'],
            directives: [movie_item_component_1.MovieItemComponent]
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
var MOVIES = [
    {
        name: "The Shawshank Redemption",
        shortName: "tsr",
        initialRelease: "September 23, 1994 (USA)",
        director: "Frank Darabont",
        storyBy: "Stephen King",
        description: "Andy Dufresne, a successful banker, is arrested for the murders of his wife and her lover, and is sentenced to life imprisonment at the Shawshank prison. He becomes the most unconventional prisoner."
    },
    {
        name: "The Godfather",
        shortName: "tgf",
        initialRelease: "March 15, 1972 (New York City)",
        director: "Francis Ford Coppola",
        storyBy: "Mario Puzo",
        description: "Don Vito Corleone, head of a mafia family, decides to hand over his empire to his youngest son Michael. However, his decision unintentionally puts the lives of his loved ones in grave danger."
    },
    {
        name: "The Dark Knight",
        shortName: "tdk",
        initialRelease: "July 18, 2008 (India)",
        director: "Christopher Nolan",
        storyBy: "",
        description: "Batman has a new foe, the Joker, who is an accomplished criminal hell-bent on decimating Gotham City. Together with Gordon and Harvey Dent, Batman struggles to thwart the Joker before it is too late."
    },
    {
        name: "Schindler's List",
        shortName: "scl",
        initialRelease: "November 30, 1993 (DC)",
        director: "Steven Spielberg",
        storyBy: "",
        description: "Oskar Schindler, a German industrialist and member of the Nazi party, tries to save his Jewish employees after witnessing the persecution of Jews in Poland."
    }
];

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLHFCQUEwQixlQUFlLENBQUMsQ0FBQTtBQUMxQyxxQ0FBbUMsd0JBQXdCLENBQUMsQ0FBQTtBQWtCNUQ7SUFBQTtRQUNFLFdBQU0sR0FBRyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQVREO1FBQUMsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxXQUFXO1lBQ3JCLFdBQVcsRUFBRSx1QkFBdUI7WUFDcEMsU0FBUyxFQUFFLENBQUMsaUJBQWlCLENBQUM7WUFDOUIsVUFBVSxFQUFFLENBQUMseUNBQWtCLENBQUM7U0FDakMsQ0FBQzs7b0JBQUE7SUFJRixtQkFBQztBQUFELENBRkEsQUFFQyxJQUFBO0FBRlksb0JBQVksZUFFeEIsQ0FBQTtBQUVELElBQUksTUFBTSxHQUFZO0lBQ3BCO1FBQ0UsSUFBSSxFQUFFLDBCQUEwQjtRQUNoQyxTQUFTLEVBQUUsS0FBSztRQUNoQixjQUFjLEVBQUUsMEJBQTBCO1FBQzFDLFFBQVEsRUFBRSxnQkFBZ0I7UUFDMUIsT0FBTyxFQUFFLGNBQWM7UUFDdkIsV0FBVyxFQUFFLHdNQUF3TTtLQUN0TjtJQUNEO1FBQ0UsSUFBSSxFQUFFLGVBQWU7UUFDckIsU0FBUyxFQUFFLEtBQUs7UUFDaEIsY0FBYyxFQUFFLGdDQUFnQztRQUNoRCxRQUFRLEVBQUUsc0JBQXNCO1FBQ2hDLE9BQU8sRUFBRSxZQUFZO1FBQ3JCLFdBQVcsRUFBRSxpTUFBaU07S0FDL007SUFDRDtRQUNFLElBQUksRUFBRSxpQkFBaUI7UUFDdkIsU0FBUyxFQUFFLEtBQUs7UUFDaEIsY0FBYyxFQUFFLHVCQUF1QjtRQUN2QyxRQUFRLEVBQUUsbUJBQW1CO1FBQzdCLE9BQU8sRUFBRSxFQUFFO1FBQ1gsV0FBVyxFQUFFLHlNQUF5TTtLQUN2TjtJQUNEO1FBQ0UsSUFBSSxFQUFFLGtCQUFrQjtRQUN4QixTQUFTLEVBQUUsS0FBSztRQUNoQixjQUFjLEVBQUUsd0JBQXdCO1FBQ3hDLFFBQVEsRUFBRSxrQkFBa0I7UUFDNUIsT0FBTyxFQUFFLEVBQUU7UUFDWCxXQUFXLEVBQUUsOEpBQThKO0tBQzVLO0NBQ0YsQ0FBQSIsImZpbGUiOiJhcHAuY29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNb3ZpZUl0ZW1Db21wb25lbnQgfSBmcm9tICcuL21vdmllLWl0ZW0uY29tcG9uZW50JztcblxuaW50ZXJmYWNlIEFydGlzdCB7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIHNob3J0TmFtZTogc3RyaW5nO1xuICAgIGluaXRpYWxSZWxlYXNlOiBzdHJpbmc7XG4gICAgZGlyZWN0b3I6IHN0cmluZztcbiAgICBzdG9yeUJ5OiBzdHJpbmc7XG4gICAgZGVzY3JpcHRpb246IHN0cmluZztcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbW92aWUtYXBwJyxcbiAgdGVtcGxhdGVVcmw6ICdhcHAvcGFydGlhbHMvYXBwLmh0bWwnLFxuICBzdHlsZVVybHM6IFsnYXBwL2Nzcy9hcHAuY3NzJ10sXG4gIGRpcmVjdGl2ZXM6IFtNb3ZpZUl0ZW1Db21wb25lbnRdXG59KVxuXG5leHBvcnQgY2xhc3MgQXBwQ29tcG9uZW50IHtcbiAgbW92aWVzID0gTU9WSUVTO1xufVxuXG52YXIgTU9WSUVTOiBNb3ZpZVtdID0gW1xuICB7XG4gICAgbmFtZTogXCJUaGUgU2hhd3NoYW5rIFJlZGVtcHRpb25cIixcbiAgICBzaG9ydE5hbWU6IFwidHNyXCIsXG4gICAgaW5pdGlhbFJlbGVhc2U6IFwiU2VwdGVtYmVyIDIzLCAxOTk0IChVU0EpXCIsXG4gICAgZGlyZWN0b3I6IFwiRnJhbmsgRGFyYWJvbnRcIixcbiAgICBzdG9yeUJ5OiBcIlN0ZXBoZW4gS2luZ1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkFuZHkgRHVmcmVzbmUsIGEgc3VjY2Vzc2Z1bCBiYW5rZXIsIGlzIGFycmVzdGVkIGZvciB0aGUgbXVyZGVycyBvZiBoaXMgd2lmZSBhbmQgaGVyIGxvdmVyLCBhbmQgaXMgc2VudGVuY2VkIHRvIGxpZmUgaW1wcmlzb25tZW50IGF0IHRoZSBTaGF3c2hhbmsgcHJpc29uLiBIZSBiZWNvbWVzIHRoZSBtb3N0IHVuY29udmVudGlvbmFsIHByaXNvbmVyLlwiXG4gIH0sXG4gIHtcbiAgICBuYW1lOiBcIlRoZSBHb2RmYXRoZXJcIixcbiAgICBzaG9ydE5hbWU6IFwidGdmXCIsXG4gICAgaW5pdGlhbFJlbGVhc2U6IFwiTWFyY2ggMTUsIDE5NzIgKE5ldyBZb3JrIENpdHkpXCIsXG4gICAgZGlyZWN0b3I6IFwiRnJhbmNpcyBGb3JkIENvcHBvbGFcIixcbiAgICBzdG9yeUJ5OiBcIk1hcmlvIFB1em9cIixcbiAgICBkZXNjcmlwdGlvbjogXCJEb24gVml0byBDb3JsZW9uZSwgaGVhZCBvZiBhIG1hZmlhIGZhbWlseSwgZGVjaWRlcyB0byBoYW5kIG92ZXIgaGlzIGVtcGlyZSB0byBoaXMgeW91bmdlc3Qgc29uIE1pY2hhZWwuIEhvd2V2ZXIsIGhpcyBkZWNpc2lvbiB1bmludGVudGlvbmFsbHkgcHV0cyB0aGUgbGl2ZXMgb2YgaGlzIGxvdmVkIG9uZXMgaW4gZ3JhdmUgZGFuZ2VyLlwiXG4gIH0sXG4gIHtcbiAgICBuYW1lOiBcIlRoZSBEYXJrIEtuaWdodFwiLFxuICAgIHNob3J0TmFtZTogXCJ0ZGtcIixcbiAgICBpbml0aWFsUmVsZWFzZTogXCJKdWx5IDE4LCAyMDA4IChJbmRpYSlcIixcbiAgICBkaXJlY3RvcjogXCJDaHJpc3RvcGhlciBOb2xhblwiLFxuICAgIHN0b3J5Qnk6IFwiXCIsXG4gICAgZGVzY3JpcHRpb246IFwiQmF0bWFuIGhhcyBhIG5ldyBmb2UsIHRoZSBKb2tlciwgd2hvIGlzIGFuIGFjY29tcGxpc2hlZCBjcmltaW5hbCBoZWxsLWJlbnQgb24gZGVjaW1hdGluZyBHb3RoYW0gQ2l0eS4gVG9nZXRoZXIgd2l0aCBHb3Jkb24gYW5kIEhhcnZleSBEZW50LCBCYXRtYW4gc3RydWdnbGVzIHRvIHRod2FydCB0aGUgSm9rZXIgYmVmb3JlIGl0IGlzIHRvbyBsYXRlLlwiXG4gIH0sXG4gIHtcbiAgICBuYW1lOiBcIlNjaGluZGxlcidzIExpc3RcIixcbiAgICBzaG9ydE5hbWU6IFwic2NsXCIsXG4gICAgaW5pdGlhbFJlbGVhc2U6IFwiTm92ZW1iZXIgMzAsIDE5OTMgKERDKVwiLFxuICAgIGRpcmVjdG9yOiBcIlN0ZXZlbiBTcGllbGJlcmdcIixcbiAgICBzdG9yeUJ5OiBcIlwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIk9za2FyIFNjaGluZGxlciwgYSBHZXJtYW4gaW5kdXN0cmlhbGlzdCBhbmQgbWVtYmVyIG9mIHRoZSBOYXppIHBhcnR5LCB0cmllcyB0byBzYXZlIGhpcyBKZXdpc2ggZW1wbG95ZWVzIGFmdGVyIHdpdG5lc3NpbmcgdGhlIHBlcnNlY3V0aW9uIG9mIEpld3MgaW4gUG9sYW5kLlwiXG4gIH1cbl1cbiJdfQ==
